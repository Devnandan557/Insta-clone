var spn = document.querySelector('#spn');
var paraOne = document.querySelector('#para1');
var dots = document.querySelector('#dots');

var footer = document.querySelector('.footer');

// ----------------- Read More feature ----------------- //

function myfun() {
  if (spn.style.display === 'none') {
    spn.style.display = 'inline';
    dots.style.display = 'none';
  }
  else {
    spn.style.display = 'none';
    dots.style.display = 'inline';
  }

}


// ----------------- Highlights feature ----------------- //

var highlights = [

  {
    img1: "images/hulk.jpg", hgltImg1: "images/hulk.jpg"
  },

  {
    img1: "images/hulk.jpg", hgltImg1: "images/forest.jpg"
  },

  {
    img1: "images/hulk.jpg", hgltImg1: "images/thor.jpg"
  },

  {
    img1: "images/hulk.jpg", hgltImg1: "images/forest2.jpg"
  }


]

var allHglt = document.querySelector('.allHglt');

var clutter = ""

var hgltImg1 = document.querySelector('#hgltImg1');
var hgltImg = document.querySelector('.hgltImg');

var img1 = document.querySelector('#img1');

var fullScreen = document.querySelector('.fullScreen');
var highlightss = document.querySelector('.highlightss');

highlights.forEach(function (elem, idx) {
  //console.log(idx);
  //console.log(elem);
  clutter += `<div class="highlights">
  <div class="hglt">
      <img id="${idx}" src="${elem.img1}" alt="">
      <p>Hulk</p>
  </div>
</div>
`

});

highlightss.innerHTML = clutter;

highlightss.addEventListener('click', function (dets) {

  fullScreen.style.display = "block";
  fullScreen.style.backgroundImage = `url(${highlights[dets.target.id].hgltImg1})`;
  highlightss.style.display = "none";
  footer.style.display = "none";

  setTimeout(function () {
    fullScreen.style.display = "none";
    highlightss.style.display = "flex";
    footer.style.display = "block";

  }, 3000);

})



var files = document.querySelector('#files');
var images = document.querySelector('.images');
var taggedImgs = document.querySelector('.taggedImgs');
var file = document.getElementById('file');

// var flag = 0;

taggedImgs.style.display = ' none';

files.addEventListener('click', function(){
  // console.log('hiiii');
  taggedImgs.style.display = 'flex';
  files.style.borderBottom = "3px solid #111";
  file.style.borderBottom = 'none';
  images.style.display = 'none';  
})

file.addEventListener('click', function(){
  files.style.borderBottom = "none";
  file.style.borderBottom = '3px solid #111';

  taggedImgs.style.display = 'none';
  images.style.display = 'flex';
})


var menu = document.getElementById('menu');

var menuBar = document.querySelector('.menuBar')
var ulitems = document.querySelector('.ulitems')
var usrStats = document.querySelector('.usrStats')


$(document).ready(function () {
  $("#mnu").click(function () {
      //$("#myDIV").css('display', 'block');
      
      // $("#myDIV").css("display", "block");
      $("#myDIV").toggle();
      
  });
});









