var container = document.querySelector('.container');
var boxes = document.querySelector('.boxes');
var box1 = document.querySelector('.box1');
var box2 = document.querySelector('.box2');
var box3 = document.querySelector('.box3');
var box = document.querySelectorAll('#box');
//const url = 'https://api.adorable.io/avatars/';


// function randomBoxes(){
    // box.forEach(function(elem){
    //     console.log(elem);
    //     //boxes.innerHTML = elem;
    //     boxes = boxes + elem;
    // })
//}










// function getRandom(){
//     return Math.floor(Math.random() * 10);
// }
// getRandom();

// var imagesTot = 10;

// function loadImages(){
// for(i=0; i<imagesTot; i++){
//     var img = document.createElement('img');
//     img.src = `${url}${getRandom()}`;
//     container.appendChild(img); 
// }
// }

// loadImages()

var myBox = ""

window.addEventListener('scroll', () => {
    //console.log(dets);
    if(window.scrollY + window.innerHeight >= document.documentElement.scrollHeight){
        box.forEach(function(){
            //console.log();
            myBox += `<div class="box1" id="box">

            </div>`

            boxes.innerHTML = myBox;
            console.log(boxes);
            document.write(boxes);
            //document.write(boxes);
            //boxes.innerHTML = elem;
            //boxes = boxes + elem;
        })

    }
})

// function loadImages(){
//     var imgs = 
// }





//console.log(getRandom());