var footer = document.querySelector('.footer');

var arr = [

    {
        dp: "images/hulk.jpg",
        story: "images/hulks.jpg"
    },

    {
        dp: "images/hulk.jpg",
        story: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFhUYGBgYGBgYGBgYGBgYGBkYGBgaGRgYGhgcIS4lHB4rHxgYJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISGjQhISs0NDQ0NDE0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0MTQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAMIBAwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAACBQYBB//EADkQAAEDAgQEAgkCBgIDAAAAAAEAAhEDIQQSMUEFUWFxgZEGEyIyobHB0fBC8RRSYnKS4RUjM4Ky/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAECAwT/xAAgEQEBAQEBAAIBBQAAAAAAAAAAARECIRIxAyIyQVFh/9oADAMBAAIRAxEAPwD6hkXkIpVJWkWaF65ijSrSgXdTVTTTULxzUCuVM0aaplRqbgEBmNXr2AiCgnEt5r2niWkwCorH4p6M06gJAh3RcRxLhjqRghfVwVhcf4Uao9mJW+OrL6x1z/T5tK9a9O47g9VmrDCz4IXbyue4LmRWlLtKI0rNblXKMziORpL3Q0ak7BLOeuY4/jn5yzMAyLtGp7lTqTPV56y+NjiHpQyYY0OaNXGW32i3Nc/i+IPqTcACS06HawIvvqssvPPqvGzMx53nrBXP6bt37O0sdWJj1rmxckueR5XPLZOUeN1GPhzs7dD589lhuDvePPXqr1S4zqAbkbJuI7DDcWBPtw3QgaEg7ibO0WjMr5wSbHS2x5Ld4JxMA5XPiRYEQ2ZHlYuv0W+ev7Z65dQ4KqvqpkXVyxVWyr1rFCmmIGq7WKMR2rNrXMUawpilRlRjU1QbdYtdeeVP4QqLTaAvVj5V2+MdWCvHBUDlC5RxWDlcPQgrNQHD1V7lUleSggevKjhGqFUfCUqPKQSo4IuBYSZSrWymcM8sKrLbYLKwQ6NYOFlYlZbeVaTXCCAVzXF/RsPBLLFdQ1eOCs6sSyV8pxXCKjDBaUi8EWK+tYnDNd7wXF+k/Dmt9pgXXnrftzvOOPx5/wCt5zFsNJzDURdcM95dckknnddR6S1i2mGAwXugjfKLn45fNc0KRBhwIOsEEHyU7vq8/T1jJ1RDRN43hEo05/3ZMspX+K5W42DhsMXOAcNIHkdV12E4W39QBB37rn/4trCJ15AT5rd4Pxmk4BrnljuTtO64d/K+tQ1ifRKm9kgQ6Gx3A5+PwXH47gr6TvdJbv8A0k2g+MXX1bDEwWk6RroQdwVKmFa4kFs5hF/zspx3ZVscrw8nI0OEECD4JssRa1MC0RCDC92uGrABeOpyrsCIXhXUJ5YRmFRwBUDQmk8GplOUnrPaYTFNyx1HbnrGhnUSecqLPxdPnHZh69DpQC9XY9RyNsYrhAbWUdVQGe9LPqoFXEQlH4hMTTb6kqNSXrldlVMQ60I7WBK03Jym5Vp7Sluica+UqHKwYdVA6xyJmWZ60hFZXUNM1CsDiuhBEraD5WdxUNaxz3GA0FxPIASSrEr5J6R0m+uF4IaAP6QS5ziOpAaJWA94cSxoMGMubUH9V7mNE7xDFF9V9R0tzuDmj+VoGVgI/tAnulXUw2XtPvAAiZ0Oo3/Zc+r+rSfQ7KbWNvc7KzabnaRPkkS4neUWnWI0Tr1YHi6L2XLdd4slcQf5gRuCNtF2PBscHDK8Bw0vdaOJ4NhTd7TJ0a237Ln88vsaxyno96R1aLmscc7IytBuRfSdSF3WJ9IKbA3Ocsg7GbkeK4/DUaD3ucwMphpIa3NLjl1N+y1OIcMFV1Gu5wczJkeDJJLSS0HuHHX+VLnXWJuH341lUueycpcYkRoq51QwBAAAGgFgPBBLl65MmOVGfVQXVUJz1TMqDiorNrJUFGaqGW1UdlcJGVM6DR/iAos7OVFB3LaiKKizG1lf1y5400xVXjqyzRiF6+urgvVq9Us6qgVq90B1VXC04KiaolZdF62sG1QhqimWPRKNMQiZFNaBY85k80kpV9RjLucB3MJCv6TU2Wa1zz0sP8j9JUtg0a7UBr43XPYvjlZ+gawH+X2nf5G3wWVVDne85zj/AFEn9li/kkHav4lTYJe9o8ZPgBcrjvSr0hdUYWMa4MO51dBtPISNP2SFanI1j5LCxeJcCWmZ+yny0whWbOsTv9Pqs6vSyQRvZOOf7XcIOOuztBVn2KMKI0SUg2qmadSyWDX4dYzFgfPktLEcRygwZdvGgHJK4Cm11LMTABOYi5EtMGEtS4WH+/Us4Ny6svmGbSROWddZ7LlZLfWjdXgrMT/2A5HC7nNEieZGxsVr8PoCkypSzFwDWul0SHbRyE/NJ0fRp7B6yhWhzcxhxkOaASbQDBgbEayr8Oxbq7PWOEF7W6WEBztvALXEt6kTryC5ghPKI6mh5V7McNUleZU03DEozMGdYRdIBhVw1MvbCjWSgAGqzWIxYrNYhQci9TOReImtH1sIZxCVL1WVhrTzKq9fVslWPVqglU0J1SURrkL1aNTYiC4da2HqQksPSTLQpWo0WY0hI8Q9JQyWtOZ/wHdYfGuIkOFJpgkSYN4+m6yqdMmYHadO659dZ5FaIxjqj8z3F19zad4CHxDEZQItJXuEwpaNRP5uj18LnEEhcL16sj2hUBaDdHBtI+KpgMIGmHGBz28TsmcbUb7LWEHspfW5CZp5pEeK5/j+HytB5W+31HkutbRA9k6xKxuNslpA0v5FZlsq2eOJc67eyj7thMYumQB0QiyInSy9GsMeqC0wVanUTlemHLPfRha3Rr4PHlrS2bO1Cd4djLhpMDbePguaYb6pjD1y0gqXkd26vi2e0wMqMicvhy891qYDK9jXhgZNixogAgwbbLj8Jxq4BPT8+Hku34eCGNkQTcjuZv10U/HzZ19JfoKrhjslH4cha7lSF6Z053lTBUxF08YiEo2yIKgWasL4rAzdDo4OE46rsql6aYVfh1dlBHZUE3TjWAiU1cZvqlFpeqaommMgNAVXwlnYhCdiEQcOTLHrMNZXp10Gq0AotJiz6eITrKiB+kk8fxZrTkZ7TvgEnj8WYytNzr0CwX1g2QP/AGJ1PTsuXXWeRqH6uKAJcQC51yYEnuUBuMJIAgc/ss2pVmTKpSqDMFzHTsrmLI/rTASGEEhPUhaDr1XOtQxTfZBdEyIEGeXiCrYY6zpzQwRc315fZYaGfWJkkz1OvnFknXFiCNZ6/JFpPuI8leozcDuOaWK52vgQSfwJPE4GGGeVl0j8M2SbtPmEHHtJLMwADG5R/Kbk66brfPVjLinMOVKvbouu/g2OOUCziIPTUN8wEOt6P5hYQQMw6xfnyXSdQxygwpcRlEkn4nRdfgPRSk1oNUF79SJIYOkC58UbhHDmtfLolozW75R9VuVBdb46+VZ68L4bCUmRkpsbGmVjQfOE+1yVRWErsws9xS/rLo1QmEk8mUgburMYZQ6FZNioFBV7IS76iLWqSEg9yAhqotLG5VnOeqZ1cG7/AMgFFhyvEw0Bz1RxRnMQnNVSqZ1Zj0NwXgKDSoPA1R3YrYLMaVTE1crDfWwWb5FCfi5cTzJPgLD5JCrVkoXrEIuXBo2y4KDScMyJhngyOlks55aSI3/Pkn+NOnwFQRFlrsC5/h1SwgLoMMJv+R9lxs9INGUZpsZHTbVBEXCLXIDYKSwr5MHz7c1GjGCpyexKcrU4g7q2Cp30/LJmo0EEeKZ4rCxggyBZDpVSRvPIcuvNNY9lpSTRcRabGfmiVcEbtB6C3lG6coVBfUwLA7RcAHlokWVAfy/mrNrQd73VNOYPBtio+faD2iJvlGV2k6QX+SbxNMTrDvgeyQeA5omxMgOFiJvHZD/5F7HBtRuYWhzdbfy9ehWues9hcoxlHpvXr6eYBwIMiQefQ8j3QKbl6ee51HOzDmoSdXCo/rYQqmJhaCzaRBRHVFDiJQy4KotqhVGEIzCilsojMcFTInKlNAAVFfVqIsqIBVGILmLUqUUE0VNGa6mq+rWm6iqeoTUIhiR4i/2g3lc9ytxzA1pcdACT4CVzwp5gXOOXNeSsd3zGozXnqgl69rCEt6zZYbOYavDgrYmxkaJEPunc+ZqzfKY0uFV3bRb7rrcK6RPK/wBx0XBYF5a4LteG1wRLrdj8Y5Ll1MpB+I4oRldY6h21rIGBI3v90vxkxFxfdKYZwClV1OHeBob8pTFTEDLprbxWBRxH7ogxZJjbb5BTVO1SCx5PKNJv91iNeT7p1trfqm+J4iGZWnW7vos3BvjNI1jl4/RWfSU4GHl+cky2kTEi6HRqA7zyTQOkeSCVGBogpTEAmARIBDgJvLTJAO0/VPPaWiSEu+q0t0125fl1Io7MXQLBkzsf+troyWm9tLz8FG1QRO/TfoN/2WY8Bn6cxcY1ghw35QfojNq6A66Fbl/mF9h+Qh1g0qPaRpol3OXp56+U1zvjzKF7mVFA1bQZj0UPS2VGpBQXLUu9hlNwoGIFMhUT/q1FdMNOooDsMtUU176tZ1cY5w689StV1JCdSTTGBxdwazLu+0dP1H85rl8TWzHkBYJ7jGPz1HwbNORvZuvmZWXRuVy6u3VkK12pFzCtivhko2hKSzFIlqvh6sFazOGE2GqjuDELN6gWY6DOy6XhdUFoi3cLDqYFwF/t5LQwpLAByAHY91jqyq0OJNGo/crPD7dOY/NVqUznFzHSJkeCuODWmT/j/sLEKQo1bTCWxnFms3k8hrK08Xg2spue4khrXO/xBt8F89Y7+a53K3zz8vUb9DjJc72tzdaLcW06RePguWp6pmmSN1vrmDqMPiSNFo4evcSQuXoVufmtKhitPuudmDs2sa9ulvtvJWbWZMgiPJB4bjJET+d0TEPm8xP3UrWs7EtIEjWZ8JkfJOZ3mH5ATAGYFpudbT0N+6XxVM5HX0F+gj91ZnFDUDWZGtygZi0a/nLqkDDapy33t/tWbSMXQnkmLQE1RXX8N9xjqFyxRrEd7UJehl6GozFRoVwUBQURhCWL0F1VDWh6wKLN9aohrqQrtQmFMMCyqhah1bAnkCfIJqEOpTkEcwQjT4y6obmfFHwbkrWEGOSvRfF1zs8D2Lfa26VpG6Nh2F5E6LRZgQBP+1jcmD3AvER1W1hmB09BJPQmyy6VDlY9NbrVwUstGuvWNFypDA4WHDMBzjlO6yMVhwwwurZig1h+S5nGVpdtrqqti+BYZvp3XV8NgtuPP8suYwl10mDIaz3lYcuf9IWf9Vcf0Oj5fZfNX4YhfSeP1x6qq7QGB5uAXHiD2V56xKwphHp4jmtCtgA64Wa/CPGgXSWUPNqgp7Dv0jyGqtwTDURZ7M7uung3RdMzKG+yA0dAB8lz6sngx8LhamdxyuDdpMA991pMwVQNlkOiSWix7ZTql62OABt9lbhfHAHXFtr37H7hZu1YIcVmY8OH6SOxP+0DhbGZjmdlt3vbaVpY7Ctec7RBd7w/qjWO3yWa/AZrizwe0jZINFtRoMC/UlNUO8rAosIdlOunZdFRZAhdfxT9Ws9VHhDLEUodWoGiSvQyE+oAhvxjRukXYtriTJASFd4Jtog18VjgBYrLGIJdJKqynKPTpMNiTKoJ/GdFFf1LFEV2zEdiGxqOwLIuAvXMV2hEyKNPh3FWZar26Q9w8iQh4YT4XK0PSxmXF1R/WT53+qWpsytE6m5WAeg8DvF5TtOsA4SdBPist1WEE4gjssXnWXR03zcAJxmIc3YHlaVytDGxoU8zitrrF4adA+tmEC3c27LNxDi0w4EHb83QcNjgdbJ5lQGL5gdnCRos5gFhsRl3haLMWTaVn1MIDdjsp5G7T46j4oDXuZ7/ALI25dTKA3pRiIotZu9wJ10b7R+OVYeDBsdQg4ziPrXkkENFmf28z1OqlJpF2kjny8RutyZMGgGsEu934rPxGIm8WGg+q8fiM2pt8FQGbla55HuDa9xLmNJjkLrZ4Zjn5gzIXAXMiC3xKDwquGmNJWzTc3MGNF3uyu0vv5LHV9+iEOKcSFMiiGtzPF7h2UHR0jvos2hiQ0CzSdZIBv4qcboBtYvazK0+y11vacPeNt1bA4MRMyev0VkmDquCY5xaQR3ECTHKN0zWpBrw8Xa4a9WnQ+B+Cz+D04c0DxkfnVbWLcx7gzNYkRpJLbz+c1zvjRY4RheKmpiNbTzjnH1TTmQvKTCww4W57LzHYhrWmd9F6vxftc+vshW4gGnRZWOxxfYWCDWqa7pZpkroGH0wGjmUAdk1UAIBlCYyddFUOYagcsxPRBl19G9DqtrANpsZnc665f0ix7HvGQEAanRRcPZHHmosqnj4A9pyiLj6ywozCsHF8epUjDneV0ajxuk5uYOUxNbzUULicT6UuBIa23NPcF9Is5yuseamLrhfS1wOMqnYPj/ER9FmPrp3jftYmqeb3x3zOj6LCc9YU056q5L+sXnrUwMZVANvzug+uVhWsgdYwgJzDYkt5ws6hih7p8OqIa1oWLBtVcb7Ii2mnNL1MdmBaYIOoIkHwWY6vI16FAbU6pOYGatFv6fZ7XHxuhF5jKD4/RXY9u/+kPEVBt8FrAKo/bYKoqSqA81QlUO0a8GU/geJZKzHnRpv2Nj81glyOx6l5lHS1nsc91OoYYX5qbx+h94n+kgwU+zAlkTr5rmWYibG8iDK6z0ffmZlfeB7JOo2H0XLqYsP4ajlBfMcu6x6VY1K4INmGBuL6/nRO+kOO9VSygjO72BHM+84dgk/R2mWw6xmRG6x/q11BfnsbHaSTfxWTxHDkggWImRPLcL1+IOax7xrflNj2T+snmrz1Z7Es1xNSo5pgoD6p2W5xnA3kDr4brFdheRXs562azg+EqGLpnDVQ50bdEkyg4D2muA5kEDzRWU4uJAV1G1jmtDLTK5OtTJcVvMqDc+aTrZJsixn+oHVRNW5rxTVVxh9s90bDaqKLTJluqLw73ioogx+I/8Akd/c7/6WVifeP9x+aii4tAhQqKKjxelRRB4fsmnaqKKUUfqqt1XqiD0qpXqiFRUd9l4ogq1elRRUEZ9V1fBXmGXP6d+qii5/k+linpL79P8Atd8wtTB6DwUUXK/UKNU1WlQ+y9UUT+S3Evd8T8ll8PYMxsNeSii7T9hft0WAEtcDcQbG6wHtGR1tz816on4fupWVU9wrOpKKLvSIoooiv//Z"
    },

    {
        dp: "images/hulk.jpg",
        story: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFhUYGBgYGBgYGBgYGBgYGBkYGBgaGRgYGhgcIS4lHB4rHxgYJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISGjQhISs0NDQ0NDE0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0MTQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAMIBAwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAACBQYBB//EADkQAAEDAgQEAgkCBgIDAAAAAAEAAhEDIQQSMUEFUWFxgZEGEyIyobHB0fBC8RRSYnKS4RUjM4Ky/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAECAwT/xAAgEQEBAQEBAAIBBQAAAAAAAAAAARECIRIxAyIyQVFh/9oADAMBAAIRAxEAPwD6hkXkIpVJWkWaF65ijSrSgXdTVTTTULxzUCuVM0aaplRqbgEBmNXr2AiCgnEt5r2niWkwCorH4p6M06gJAh3RcRxLhjqRghfVwVhcf4Uao9mJW+OrL6x1z/T5tK9a9O47g9VmrDCz4IXbyue4LmRWlLtKI0rNblXKMziORpL3Q0ak7BLOeuY4/jn5yzMAyLtGp7lTqTPV56y+NjiHpQyYY0OaNXGW32i3Nc/i+IPqTcACS06HawIvvqssvPPqvGzMx53nrBXP6bt37O0sdWJj1rmxckueR5XPLZOUeN1GPhzs7dD589lhuDvePPXqr1S4zqAbkbJuI7DDcWBPtw3QgaEg7ibO0WjMr5wSbHS2x5Ld4JxMA5XPiRYEQ2ZHlYuv0W+ev7Z65dQ4KqvqpkXVyxVWyr1rFCmmIGq7WKMR2rNrXMUawpilRlRjU1QbdYtdeeVP4QqLTaAvVj5V2+MdWCvHBUDlC5RxWDlcPQgrNQHD1V7lUleSggevKjhGqFUfCUqPKQSo4IuBYSZSrWymcM8sKrLbYLKwQ6NYOFlYlZbeVaTXCCAVzXF/RsPBLLFdQ1eOCs6sSyV8pxXCKjDBaUi8EWK+tYnDNd7wXF+k/Dmt9pgXXnrftzvOOPx5/wCt5zFsNJzDURdcM95dckknnddR6S1i2mGAwXugjfKLn45fNc0KRBhwIOsEEHyU7vq8/T1jJ1RDRN43hEo05/3ZMspX+K5W42DhsMXOAcNIHkdV12E4W39QBB37rn/4trCJ15AT5rd4Pxmk4BrnljuTtO64d/K+tQ1ifRKm9kgQ6Gx3A5+PwXH47gr6TvdJbv8A0k2g+MXX1bDEwWk6RroQdwVKmFa4kFs5hF/zspx3ZVscrw8nI0OEECD4JssRa1MC0RCDC92uGrABeOpyrsCIXhXUJ5YRmFRwBUDQmk8GplOUnrPaYTFNyx1HbnrGhnUSecqLPxdPnHZh69DpQC9XY9RyNsYrhAbWUdVQGe9LPqoFXEQlH4hMTTb6kqNSXrldlVMQ60I7WBK03Jym5Vp7Sluica+UqHKwYdVA6xyJmWZ60hFZXUNM1CsDiuhBEraD5WdxUNaxz3GA0FxPIASSrEr5J6R0m+uF4IaAP6QS5ziOpAaJWA94cSxoMGMubUH9V7mNE7xDFF9V9R0tzuDmj+VoGVgI/tAnulXUw2XtPvAAiZ0Oo3/Zc+r+rSfQ7KbWNvc7KzabnaRPkkS4neUWnWI0Tr1YHi6L2XLdd4slcQf5gRuCNtF2PBscHDK8Bw0vdaOJ4NhTd7TJ0a237Ln88vsaxyno96R1aLmscc7IytBuRfSdSF3WJ9IKbA3Ocsg7GbkeK4/DUaD3ucwMphpIa3NLjl1N+y1OIcMFV1Gu5wczJkeDJJLSS0HuHHX+VLnXWJuH341lUueycpcYkRoq51QwBAAAGgFgPBBLl65MmOVGfVQXVUJz1TMqDiorNrJUFGaqGW1UdlcJGVM6DR/iAos7OVFB3LaiKKizG1lf1y5400xVXjqyzRiF6+urgvVq9Us6qgVq90B1VXC04KiaolZdF62sG1QhqimWPRKNMQiZFNaBY85k80kpV9RjLucB3MJCv6TU2Wa1zz0sP8j9JUtg0a7UBr43XPYvjlZ+gawH+X2nf5G3wWVVDne85zj/AFEn9li/kkHav4lTYJe9o8ZPgBcrjvSr0hdUYWMa4MO51dBtPISNP2SFanI1j5LCxeJcCWmZ+yny0whWbOsTv9Pqs6vSyQRvZOOf7XcIOOuztBVn2KMKI0SUg2qmadSyWDX4dYzFgfPktLEcRygwZdvGgHJK4Cm11LMTABOYi5EtMGEtS4WH+/Us4Ny6svmGbSROWddZ7LlZLfWjdXgrMT/2A5HC7nNEieZGxsVr8PoCkypSzFwDWul0SHbRyE/NJ0fRp7B6yhWhzcxhxkOaASbQDBgbEayr8Oxbq7PWOEF7W6WEBztvALXEt6kTryC5ghPKI6mh5V7McNUleZU03DEozMGdYRdIBhVw1MvbCjWSgAGqzWIxYrNYhQci9TOReImtH1sIZxCVL1WVhrTzKq9fVslWPVqglU0J1SURrkL1aNTYiC4da2HqQksPSTLQpWo0WY0hI8Q9JQyWtOZ/wHdYfGuIkOFJpgkSYN4+m6yqdMmYHadO659dZ5FaIxjqj8z3F19zad4CHxDEZQItJXuEwpaNRP5uj18LnEEhcL16sj2hUBaDdHBtI+KpgMIGmHGBz28TsmcbUb7LWEHspfW5CZp5pEeK5/j+HytB5W+31HkutbRA9k6xKxuNslpA0v5FZlsq2eOJc67eyj7thMYumQB0QiyInSy9GsMeqC0wVanUTlemHLPfRha3Rr4PHlrS2bO1Cd4djLhpMDbePguaYb6pjD1y0gqXkd26vi2e0wMqMicvhy891qYDK9jXhgZNixogAgwbbLj8Jxq4BPT8+Hku34eCGNkQTcjuZv10U/HzZ19JfoKrhjslH4cha7lSF6Z053lTBUxF08YiEo2yIKgWasL4rAzdDo4OE46rsql6aYVfh1dlBHZUE3TjWAiU1cZvqlFpeqaommMgNAVXwlnYhCdiEQcOTLHrMNZXp10Gq0AotJiz6eITrKiB+kk8fxZrTkZ7TvgEnj8WYytNzr0CwX1g2QP/AGJ1PTsuXXWeRqH6uKAJcQC51yYEnuUBuMJIAgc/ss2pVmTKpSqDMFzHTsrmLI/rTASGEEhPUhaDr1XOtQxTfZBdEyIEGeXiCrYY6zpzQwRc315fZYaGfWJkkz1OvnFknXFiCNZ6/JFpPuI8leozcDuOaWK52vgQSfwJPE4GGGeVl0j8M2SbtPmEHHtJLMwADG5R/Kbk66brfPVjLinMOVKvbouu/g2OOUCziIPTUN8wEOt6P5hYQQMw6xfnyXSdQxygwpcRlEkn4nRdfgPRSk1oNUF79SJIYOkC58UbhHDmtfLolozW75R9VuVBdb46+VZ68L4bCUmRkpsbGmVjQfOE+1yVRWErsws9xS/rLo1QmEk8mUgburMYZQ6FZNioFBV7IS76iLWqSEg9yAhqotLG5VnOeqZ1cG7/AMgFFhyvEw0Bz1RxRnMQnNVSqZ1Zj0NwXgKDSoPA1R3YrYLMaVTE1crDfWwWb5FCfi5cTzJPgLD5JCrVkoXrEIuXBo2y4KDScMyJhngyOlks55aSI3/Pkn+NOnwFQRFlrsC5/h1SwgLoMMJv+R9lxs9INGUZpsZHTbVBEXCLXIDYKSwr5MHz7c1GjGCpyexKcrU4g7q2Cp30/LJmo0EEeKZ4rCxggyBZDpVSRvPIcuvNNY9lpSTRcRabGfmiVcEbtB6C3lG6coVBfUwLA7RcAHlokWVAfy/mrNrQd73VNOYPBtio+faD2iJvlGV2k6QX+SbxNMTrDvgeyQeA5omxMgOFiJvHZD/5F7HBtRuYWhzdbfy9ehWues9hcoxlHpvXr6eYBwIMiQefQ8j3QKbl6ee51HOzDmoSdXCo/rYQqmJhaCzaRBRHVFDiJQy4KotqhVGEIzCilsojMcFTInKlNAAVFfVqIsqIBVGILmLUqUUE0VNGa6mq+rWm6iqeoTUIhiR4i/2g3lc9ytxzA1pcdACT4CVzwp5gXOOXNeSsd3zGozXnqgl69rCEt6zZYbOYavDgrYmxkaJEPunc+ZqzfKY0uFV3bRb7rrcK6RPK/wBx0XBYF5a4LteG1wRLrdj8Y5Ll1MpB+I4oRldY6h21rIGBI3v90vxkxFxfdKYZwClV1OHeBob8pTFTEDLprbxWBRxH7ogxZJjbb5BTVO1SCx5PKNJv91iNeT7p1trfqm+J4iGZWnW7vos3BvjNI1jl4/RWfSU4GHl+cky2kTEi6HRqA7zyTQOkeSCVGBogpTEAmARIBDgJvLTJAO0/VPPaWiSEu+q0t0125fl1Io7MXQLBkzsf+troyWm9tLz8FG1QRO/TfoN/2WY8Bn6cxcY1ghw35QfojNq6A66Fbl/mF9h+Qh1g0qPaRpol3OXp56+U1zvjzKF7mVFA1bQZj0UPS2VGpBQXLUu9hlNwoGIFMhUT/q1FdMNOooDsMtUU176tZ1cY5w689StV1JCdSTTGBxdwazLu+0dP1H85rl8TWzHkBYJ7jGPz1HwbNORvZuvmZWXRuVy6u3VkK12pFzCtivhko2hKSzFIlqvh6sFazOGE2GqjuDELN6gWY6DOy6XhdUFoi3cLDqYFwF/t5LQwpLAByAHY91jqyq0OJNGo/crPD7dOY/NVqUznFzHSJkeCuODWmT/j/sLEKQo1bTCWxnFms3k8hrK08Xg2spue4khrXO/xBt8F89Y7+a53K3zz8vUb9DjJc72tzdaLcW06RePguWp6pmmSN1vrmDqMPiSNFo4evcSQuXoVufmtKhitPuudmDs2sa9ulvtvJWbWZMgiPJB4bjJET+d0TEPm8xP3UrWs7EtIEjWZ8JkfJOZ3mH5ATAGYFpudbT0N+6XxVM5HX0F+gj91ZnFDUDWZGtygZi0a/nLqkDDapy33t/tWbSMXQnkmLQE1RXX8N9xjqFyxRrEd7UJehl6GozFRoVwUBQURhCWL0F1VDWh6wKLN9aohrqQrtQmFMMCyqhah1bAnkCfIJqEOpTkEcwQjT4y6obmfFHwbkrWEGOSvRfF1zs8D2Lfa26VpG6Nh2F5E6LRZgQBP+1jcmD3AvER1W1hmB09BJPQmyy6VDlY9NbrVwUstGuvWNFypDA4WHDMBzjlO6yMVhwwwurZig1h+S5nGVpdtrqqti+BYZvp3XV8NgtuPP8suYwl10mDIaz3lYcuf9IWf9Vcf0Oj5fZfNX4YhfSeP1x6qq7QGB5uAXHiD2V56xKwphHp4jmtCtgA64Wa/CPGgXSWUPNqgp7Dv0jyGqtwTDURZ7M7uung3RdMzKG+yA0dAB8lz6sngx8LhamdxyuDdpMA991pMwVQNlkOiSWix7ZTql62OABt9lbhfHAHXFtr37H7hZu1YIcVmY8OH6SOxP+0DhbGZjmdlt3vbaVpY7Ctec7RBd7w/qjWO3yWa/AZrizwe0jZINFtRoMC/UlNUO8rAosIdlOunZdFRZAhdfxT9Ws9VHhDLEUodWoGiSvQyE+oAhvxjRukXYtriTJASFd4Jtog18VjgBYrLGIJdJKqynKPTpMNiTKoJ/GdFFf1LFEV2zEdiGxqOwLIuAvXMV2hEyKNPh3FWZar26Q9w8iQh4YT4XK0PSxmXF1R/WT53+qWpsytE6m5WAeg8DvF5TtOsA4SdBPist1WEE4gjssXnWXR03zcAJxmIc3YHlaVytDGxoU8zitrrF4adA+tmEC3c27LNxDi0w4EHb83QcNjgdbJ5lQGL5gdnCRos5gFhsRl3haLMWTaVn1MIDdjsp5G7T46j4oDXuZ7/ALI25dTKA3pRiIotZu9wJ10b7R+OVYeDBsdQg4ziPrXkkENFmf28z1OqlJpF2kjny8RutyZMGgGsEu934rPxGIm8WGg+q8fiM2pt8FQGbla55HuDa9xLmNJjkLrZ4Zjn5gzIXAXMiC3xKDwquGmNJWzTc3MGNF3uyu0vv5LHV9+iEOKcSFMiiGtzPF7h2UHR0jvos2hiQ0CzSdZIBv4qcboBtYvazK0+y11vacPeNt1bA4MRMyev0VkmDquCY5xaQR3ECTHKN0zWpBrw8Xa4a9WnQ+B+Cz+D04c0DxkfnVbWLcx7gzNYkRpJLbz+c1zvjRY4RheKmpiNbTzjnH1TTmQvKTCww4W57LzHYhrWmd9F6vxftc+vshW4gGnRZWOxxfYWCDWqa7pZpkroGH0wGjmUAdk1UAIBlCYyddFUOYagcsxPRBl19G9DqtrANpsZnc665f0ix7HvGQEAanRRcPZHHmosqnj4A9pyiLj6ywozCsHF8epUjDneV0ajxuk5uYOUxNbzUULicT6UuBIa23NPcF9Is5yuseamLrhfS1wOMqnYPj/ER9FmPrp3jftYmqeb3x3zOj6LCc9YU056q5L+sXnrUwMZVANvzug+uVhWsgdYwgJzDYkt5ws6hih7p8OqIa1oWLBtVcb7Ii2mnNL1MdmBaYIOoIkHwWY6vI16FAbU6pOYGatFv6fZ7XHxuhF5jKD4/RXY9u/+kPEVBt8FrAKo/bYKoqSqA81QlUO0a8GU/geJZKzHnRpv2Nj81glyOx6l5lHS1nsc91OoYYX5qbx+h94n+kgwU+zAlkTr5rmWYibG8iDK6z0ffmZlfeB7JOo2H0XLqYsP4ajlBfMcu6x6VY1K4INmGBuL6/nRO+kOO9VSygjO72BHM+84dgk/R2mWw6xmRG6x/q11BfnsbHaSTfxWTxHDkggWImRPLcL1+IOax7xrflNj2T+snmrz1Z7Es1xNSo5pgoD6p2W5xnA3kDr4brFdheRXs562azg+EqGLpnDVQ50bdEkyg4D2muA5kEDzRWU4uJAV1G1jmtDLTK5OtTJcVvMqDc+aTrZJsixn+oHVRNW5rxTVVxh9s90bDaqKLTJluqLw73ioogx+I/8Akd/c7/6WVifeP9x+aii4tAhQqKKjxelRRB4fsmnaqKKUUfqqt1XqiD0qpXqiFRUd9l4ogq1elRRUEZ9V1fBXmGXP6d+qii5/k+linpL79P8Atd8wtTB6DwUUXK/UKNU1WlQ+y9UUT+S3Evd8T8ll8PYMxsNeSii7T9hft0WAEtcDcQbG6wHtGR1tz816on4fupWVU9wrOpKKLvSIoooiv//Z"
    },

    { dp: "images/hulk.jpg", story: '' },

    { dp: "images/hulk.jpg", story: '' },

    { dp: "images/hulk.jpg", story: '' }

]


var clutter = ""

var stories = document.querySelector('.stories');
var fullScreen = document.querySelector('.fullScreen');


arr.forEach(function(elem, idx){
    clutter += `<div class="story">
<img id = "${idx}" src="${elem.dp}" alt="">
</div>`

//console.log(elem);
})

stories.innerHTML = clutter;

// console.log(elem);

stories.addEventListener('click', function(dets){

    fullScreen.style.display = "block";
    fullScreen.style.backgroundImage = `url(${arr[dets.target.id].story})`;
    footer.style.display = "none";
    //fullScreen.style.backgroundImage = `url(${arr[dets.target.id].story})`;

    stories.style.display = "none";

    setTimeout(function(){
        fullScreen.style.display = "none";
        stories.style.display = "block";
        footer.style.display = "block";
        
    }, 3000);


    console.log(arr[dets.target.id].story);
})


var post = document.querySelectorAll('.post');
var like = document.querySelectorAll('#like');
var flag = 0

//console.log(like)

like.forEach(function(val){
    //console.log(val);
    

    val.addEventListener('click', function(){
        //saveData();
        if(flag === 0){
            val.style.color = 'crimson';
            flag++;
            saveData();
        }
        else if(flag === 1){
            val.style.color = '#111';
            flag--;
            saveData();
        }
        else{
            console.log('hii');
        }
        //saveData();
        
    })
})


function saveData(){
    localStorage.setItem("data", like.innerHTML);
}

function showData(){
    like.innerHTML = localStorage.getItem("data");
}

showData();


var commentBtn = document.querySelectorAll('.commentBtn');
//var commentSn = "";

var commentBx = document.querySelector('.commentBx');

commentBtn.forEach(function(val){
    console.log(val);

    val.addEventListener('click',function(){
        console.log('hello');
        //const commentSn = document.createElement('<div><input type="text" name="" id=""><button>post</button></div>'); 
        // commentSn += `
        
        // <input type="text" name="" id="">
        // <button>post</button>
       
        // `
        // commentBx.innerHTML = commentSn;
        commentBx.appendChild(commentSn);
    })

    

    
    
})



// val.childNodes[1].addEventListener('click',function(){
//     console.log('hello');
// })


// comment.addEventListener('click', function(){
//     console.log('hii');
// })





