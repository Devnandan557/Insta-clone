var search = document.querySelector('#search');
var searchBtn = document.querySelector('#searchBtn');

var man = document.querySelector('#man');
var woman = document.querySelector('#woman');
var mans = document.querySelector('#mans');
var womans = document.querySelector('#womans');
var allImg = document.querySelector('#allImg');

const manimg = document.getElementById('man');
let imgId = manimg.getAttribute('id');

const img = document.getElementById('woman');
let wimgId = img.getAttribute('id');


var manArr = ['man', 'mans', 'men', 'mens'];
var womanArr = ['woman', 'womans', 'women', 'womens'];




searchBtn.addEventListener('click', function () {
    console.log(search.value);
    for (var i = 0; i < manArr.length; i++) {
        if (search.value === manArr[i]) {
            console.log('all man');

            mans.innerHTML = man;
            mans.innerHTML =
                `<img
        src="https://res.cloudinary.com/css-tricks/image/upload/f_auto,q_auto/v1568814785/photostream-photos/DSC05586_oj8jfo.jpg"
        alt="Portrait of Justin Pervorse" loading="lazy" >
        <img
        src="https://res.cloudinary.com/css-tricks/image/upload/f_auto,q_auto/v1568814785/photostream-photos/DSC05586_oj8jfo.jpg"
        alt="Portrait of Justin Pervorse" loading="lazy" >
        `

            allImg.style.display = 'none';
            mans.style.display = 'flex';
            mans.style.justifyContent = 'center';
            mans.style.alignItems = 'flex-start';

            womans.style.display = 'none';
            search.value = '';

        }


    }

    for (var i = 0; i < womanArr.length; i++) {
        if (search.value === womanArr[i]) {
            console.log('all woman');

            womans.innerHTML = woman;

            womans.innerHTML =
                `<img
            src="https://res.cloudinary.com/css-tricks/image/upload/f_auto,q_auto/v1568814785/photostream-photos/DSC05513_gfbiwi.jpg"
            alt="Sara on a red bike" loading="lazy" id="woman">
            `

            allImg.style.display = 'none';
            womans.style.display = 'flex';
            womans.style.justifyContent = 'center';
            womans.style.alignItems = 'flex-start';

            mans.style.display = 'none';

            search.value = '';


        }
    }


});

