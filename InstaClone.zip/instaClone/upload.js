var uploadBtn = document.querySelector('.uploadBtn');
var forest = document.querySelectorAll('#forest');
var img1 = document.querySelectorAll('.img1');

//console.log(img1);

img1.forEach(function(val){
    //console.log(val);
    console.log(val.childNodes[1]);

    val.addEventListener('click', function(){
        uploadBtn.innerHTML = val.childNodes[1].src;
        uploadBtn.innerHTML = `<img src="${val.childNodes[1].src}" alt="" style="width:100%;height:100%">`
    })



})

// console.log(forest)
// forest.forEach(function(dets){

//     console.log(dets.id);

//     img1.addEventListener('click', function(){
//         uploadBtn.innerHTML = dets.src;
//         uploadBtn.innerHTML = `<img src="${dets.src}" alt="" style="width:100%;height:100%">`
//     })
    
//     })
    

// });






// forest.addEventListener('click', function(){
//    uploadBtn.innerHTML = forest.src;
//    uploadBtn.innerHTML = `<img src="${forest.src}" alt="" style="width:100%;height:100%">`
   
// })

// console.log(uploadBtn)